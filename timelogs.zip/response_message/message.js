exports.resmessage = {

    time: "Time logs added successfully.",
    timedelete: "Record Delete successfully."
}